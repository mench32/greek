import{a as t}from"../chunks/entry.Dz3Ovacz.js";export{t as start};

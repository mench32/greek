import{a as t}from"../chunks/entry.DBKpvDRq.js";export{t as start};

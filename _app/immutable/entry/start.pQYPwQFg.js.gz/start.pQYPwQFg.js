import{a as t}from"../chunks/entry.BfCSKKTr.js";export{t as start};

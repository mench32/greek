import{a as t}from"../chunks/entry.BLwUr7yb.js";export{t as start};

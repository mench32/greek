import{a as t}from"../chunks/entry.CFWS4JpU.js";export{t as start};

import{a as t}from"../chunks/entry.BxeS-nuI.js";export{t as start};

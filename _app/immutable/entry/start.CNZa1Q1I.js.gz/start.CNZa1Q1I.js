import{a as t}from"../chunks/entry.BO-Yk34-.js";export{t as start};

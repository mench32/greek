import{a as t}from"../chunks/entry.DRrnuxex.js";export{t as start};

import{a as t}from"../chunks/entry.CxR_aLFT.js";export{t as start};

import{a as t}from"../chunks/entry.EstRn-7C.js";export{t as start};

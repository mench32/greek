import{a as t}from"../chunks/entry.9lX04p7G.js";export{t as start};

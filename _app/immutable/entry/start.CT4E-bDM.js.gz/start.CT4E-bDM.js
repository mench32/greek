import{a as t}from"../chunks/entry.eRGjUlcj.js";export{t as start};

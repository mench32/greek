import{a as t}from"../chunks/entry.BGjlifkQ.js";export{t as start};

import{a as t}from"../chunks/entry.B-CHcLat.js";export{t as start};

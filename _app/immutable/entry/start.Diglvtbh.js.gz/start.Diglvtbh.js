import{a as t}from"../chunks/entry.ByVDJX_C.js";export{t as start};

import{a as t}from"../chunks/entry.DBTENYmG.js";export{t as start};

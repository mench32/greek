import{a as t}from"../chunks/entry.C7Mn6-C-.js";export{t as start};

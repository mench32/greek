import{a as t}from"../chunks/entry.DRV3wB4e.js";export{t as start};

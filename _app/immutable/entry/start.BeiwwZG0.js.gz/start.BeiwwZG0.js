import{a as t}from"../chunks/entry.BlatQaXr.js";export{t as start};

import{a as t}from"../chunks/entry.DhWFYNLX.js";export{t as start};

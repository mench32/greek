import{a as t}from"../chunks/entry.8chAr-qq.js";export{t as start};

import{a as t}from"../chunks/entry.BliSq7nh.js";export{t as start};

import{a as t}from"../chunks/entry.OwhEB5Bm.js";export{t as start};

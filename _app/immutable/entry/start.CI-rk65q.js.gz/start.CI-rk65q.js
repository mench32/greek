import{a as t}from"../chunks/entry.BedubTCk.js";export{t as start};

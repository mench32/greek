import{a as t}from"../chunks/entry.VwzUX3G9.js";export{t as start};

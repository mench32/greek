import{a as t}from"../chunks/entry.BuZj63Nq.js";export{t as start};

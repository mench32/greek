import{a as t}from"../chunks/entry.CcD9BxHq.js";export{t as start};

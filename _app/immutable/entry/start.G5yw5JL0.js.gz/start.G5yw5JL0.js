import{a as t}from"../chunks/entry.C06oMIOd.js";export{t as start};

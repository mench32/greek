import{a as t}from"../chunks/entry.BxIbHy0z.js";export{t as start};

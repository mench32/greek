import{a as t}from"../chunks/entry.Dl6k6pv5.js";export{t as start};

import{a as t}from"../chunks/entry.SrOVw0Bo.js";export{t as start};

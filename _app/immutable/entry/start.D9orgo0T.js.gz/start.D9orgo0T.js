import{a as t}from"../chunks/entry.cvl8BJKW.js";export{t as start};

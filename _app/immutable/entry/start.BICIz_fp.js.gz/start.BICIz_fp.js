import{a as t}from"../chunks/entry.C_Lo0o_p.js";export{t as start};

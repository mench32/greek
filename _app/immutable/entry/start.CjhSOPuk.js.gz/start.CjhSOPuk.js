import{a as t}from"../chunks/entry.F1po1b-M.js";export{t as start};

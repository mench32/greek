import{a as t}from"../chunks/entry.Chibff2L.js";export{t as start};

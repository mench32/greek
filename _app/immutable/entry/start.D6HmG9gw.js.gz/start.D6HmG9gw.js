import{a as t}from"../chunks/entry.DtZd8sRR.js";export{t as start};

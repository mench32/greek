import{a as t}from"../chunks/entry.CsOYH9QV.js";export{t as start};

import{a as t}from"../chunks/entry.CMvxmXGt.js";export{t as start};

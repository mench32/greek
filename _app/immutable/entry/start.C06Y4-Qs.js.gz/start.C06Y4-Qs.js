import{a as t}from"../chunks/entry.C41W-wUW.js";export{t as start};

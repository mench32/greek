import{a as t}from"../chunks/entry.BRa3I4i-.js";export{t as start};

import{a as t}from"../chunks/entry.BMD3DLb8.js";export{t as start};

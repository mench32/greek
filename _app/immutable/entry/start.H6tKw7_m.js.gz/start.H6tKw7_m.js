import{a as t}from"../chunks/entry.DGBqmNbH.js";export{t as start};

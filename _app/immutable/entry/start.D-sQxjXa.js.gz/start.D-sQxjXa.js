import{a as t}from"../chunks/entry.CI0S_kzS.js";export{t as start};

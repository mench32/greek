import{a as t}from"../chunks/entry.DVHN8HML.js";export{t as start};

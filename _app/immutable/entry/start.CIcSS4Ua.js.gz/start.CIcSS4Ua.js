import{a as t}from"../chunks/entry.PTf70QRT.js";export{t as start};

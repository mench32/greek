import{a as t}from"../chunks/entry.C5e7WMel.js";export{t as start};

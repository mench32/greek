import{a as t}from"../chunks/entry.hWSYdfqI.js";export{t as start};

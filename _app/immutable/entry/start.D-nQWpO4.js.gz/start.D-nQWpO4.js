import{a as t}from"../chunks/entry.Tg-ufS0t.js";export{t as start};

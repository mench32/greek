import{a as t}from"../chunks/entry.DAbAbbXM.js";export{t as start};

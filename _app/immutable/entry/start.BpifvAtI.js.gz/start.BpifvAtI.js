import{a as t}from"../chunks/entry.BAFpD5tn.js";export{t as start};

import{a as t}from"../chunks/entry.BBDqQuMY.js";export{t as start};

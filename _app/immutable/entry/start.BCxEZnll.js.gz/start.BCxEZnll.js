import{a as t}from"../chunks/entry.uAWlGdUP.js";export{t as start};

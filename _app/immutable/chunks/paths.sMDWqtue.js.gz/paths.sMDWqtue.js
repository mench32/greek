var s;const l=((s=globalThis.__sveltekit_1flwlud)==null?void 0:s.base)??"/greek";var e;const a=((e=globalThis.__sveltekit_1flwlud)==null?void 0:e.assets)??l;export{a,l as b};

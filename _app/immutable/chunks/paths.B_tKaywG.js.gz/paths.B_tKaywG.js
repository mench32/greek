var s;const a=((s=globalThis.__sveltekit_9bul03)==null?void 0:s.base)??"/greek";var e;const t=((e=globalThis.__sveltekit_9bul03)==null?void 0:e.assets)??a;export{t as a,a as b};

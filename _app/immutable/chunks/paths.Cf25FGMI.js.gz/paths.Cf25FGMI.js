var s;const e=((s=globalThis.__sveltekit_11c2xaq)==null?void 0:s.base)??"/greek";var a;const t=((a=globalThis.__sveltekit_11c2xaq)==null?void 0:a.assets)??e;export{t as a,e as b};

var e;const a=((e=globalThis.__sveltekit_ecyee1)==null?void 0:e.base)??"/greek";var s;const t=((s=globalThis.__sveltekit_ecyee1)==null?void 0:s.assets)??a;export{t as a,a as b};

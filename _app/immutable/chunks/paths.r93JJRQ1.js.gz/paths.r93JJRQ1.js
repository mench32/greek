var s;const a=((s=globalThis.__sveltekit_1c3msxr)==null?void 0:s.base)??"/greek";var e;const t=((e=globalThis.__sveltekit_1c3msxr)==null?void 0:e.assets)??a;export{t as a,a as b};

import{w as t}from"./index.Dxcuq5Lg.js";const e=t({showDigraphs:!1,showArticles:!1,showTranslates:!1,sound:!0});e.subscribe(s=>{localStorage.setItem("settings",JSON.stringify(s))});export{e as s};

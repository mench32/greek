var s;const t=((s=globalThis.__sveltekit_iigwt1)==null?void 0:s.base)??"/greek";var e;const a=((e=globalThis.__sveltekit_iigwt1)==null?void 0:e.assets)??t;export{a,t as b};
